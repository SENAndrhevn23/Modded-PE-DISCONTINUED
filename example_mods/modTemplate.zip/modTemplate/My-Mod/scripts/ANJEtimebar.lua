-- Custom time display for Psych Engine
-- Shows current song time / total song length in m:ss format

function onCreatePost()
    -- Hide the default time text
    setProperty('timeTxt.visible', false)

    -- Create a new text object for the custom time
    makeLuaText('customTime', '0:00/0:00', 200, getProperty('timeBar.x') + getProperty('timeBar.width') + 10, getProperty('timeBar.y') - 5)
    setTextSize('customTime', 18)
    setTextAlignment('customTime', 'left')
    addLuaText('customTime')
end

function onUpdatePost(elapsed)
    -- Get current song position and total length in seconds
    local cur = getSongPosition() / 1000
    local total = getProperty('songLength') / 1000

    -- Convert seconds to minutes and seconds
    local curMin = math.floor(cur / 60)
    local curSec = math.floor(cur % 60)
    local totalMin = math.floor(total / 60)
    local totalSec = math.floor(total % 60)

    -- Format times with leading zeros
    local curTime = string.format("%d:%02d", curMin, curSec)
    local totalTime = string.format("%d:%02d", totalMin, totalSec)

    -- Update text
    setTextString('customTime', curTime.."/"..totalTime)
end
