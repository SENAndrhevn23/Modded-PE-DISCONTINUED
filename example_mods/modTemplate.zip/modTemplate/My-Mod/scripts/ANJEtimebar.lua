-- Polished dynamic timebar: 0:00 / 0:00 format with reversed mode

-- Variables
reversedTimeTxt = false
fakeOffset = 0

function onCreatePost()
    -- Optional: hide default time text if using custom position
    setProperty('timeTxt.visible', true)  -- keep it visible for simplicity
end

function onStepHit()
    -- Example: reverse the timebar temporarily
    if curStep == 48 then
        switchReversed(true)
    end
    if curStep == 96 then
        switchReversed(false)
    end
end

function switchReversed(value)
    fakeOffset = 0
    reversedTimeTxt = value
    setProperty('updateTime', not value) -- disables default time updates if reversed
end

function onUpdatePost(elapsed)
    local songPos = getSongPosition() / 1000       -- current song position in seconds
    local total = getProperty('songLength') / 1000 -- total song length in seconds

    if reversedTimeTxt then
        fakeOffset = fakeOffset - (elapsed * 1)    -- adjust speed: 1 is normal, bigger is faster
        songPos = songPos + fakeOffset             -- apply fake offset
        songPos = math.min(math.max(songPos, 0), total)  -- clamp between 0 and total length
    end

    -- Convert to minutes and seconds
    local curMin = math.floor(songPos / 60)
    local curSec = math.floor(songPos % 60)
    local totalMin = math.floor(total / 60)
    local totalSec = math.floor(total % 60)

    -- Format times with leading zeros for seconds
    local curTime = string.format("%d:%02d", curMin, curSec)
    local totalTime = string.format("%d:%02d", totalMin, totalSec)

    -- Update the time text in 0:00 / 0:00 format
    setTextString('timeTxt', curTime.." / "..totalTime)
end